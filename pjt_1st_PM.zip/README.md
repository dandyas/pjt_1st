git&github 실습
file location// D:\github\pjt_1st_PM
:git&github 실습위해 작성한 기본 폴더 및 Readme.md 파일

: dandy, 수정함

: dandy, 1차 수정함

: dandy, 위 수정은 commit까지만 했고, 이 줄 수정 후는 push까지 진행
